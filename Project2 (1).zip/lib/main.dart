import 'package:flutter/material.dart';
import 'login_screen.dart';

void main() {
  runApp(WidgetsPracticeApp());
}

class WidgetsPracticeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Widgets Practice',
      theme: ThemeData.light(),
      initialRoute: '/',
      routes: {
        '/': (context) => LoginScreen(),
      },
    );
  }
}

void runAppWithStyle(Widget app) {
  runApp(
    MaterialApp(
      title: 'Styled Widgets App',
      theme: ThemeData(
        primarySwatch: Colors.green,
        textTheme: TextTheme(
          bodyText2: TextStyle(fontSize: 20, color: Colors.blue),
        ),
      ),
      home: app,
    ),
  );
}
