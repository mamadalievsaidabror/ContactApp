import 'package:flutter/material.dart';

class ContactListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Contact List'),
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
      ),
      body: ListView(
        children: [
          ContactCard(name: 'Professor', phoneNumber: '+99899-999-99-99'),
          ContactCard(name: 'Said', phoneNumber: '+998977-777-77-77'),
          ContactCard(name: 'Quvonch', phoneNumber: '+998912345678'),
          // Add more contacts as needed
        ],
      ),
    );
  }
}

class ContactCard extends StatelessWidget {
  final String name;
  final String phoneNumber;

  ContactCard({required this.name, required this.phoneNumber});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      child: ListTile(
        title: Text(name),
        subtitle: Text(phoneNumber),
      ),
    );
  }
}
