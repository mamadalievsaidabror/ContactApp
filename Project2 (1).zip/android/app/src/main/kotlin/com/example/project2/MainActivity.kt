package com.example.project2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
